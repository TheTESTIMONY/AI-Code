# Initial connector verification

Tested with Node 24, TypeScript, Vitest, and installed Chromium.

## Passed

- TypeScript check and production bundling.
- 11 unit tests: navigation reading, folder context, duplicate links, settings
  validation, idempotent cleanup, header replacement, password-screen rejection,
  preservation of external edits, local draft save/load, write-error reporting,
  and protection after an initial storage-read failure.
- 6 browser fixture checks: built sidebar/navigation rendering, live preview
  settings, truthful unavailable storage/publishing states, close cleanup,
  390px fit and Escape cleanup, no page errors.
- Impeccable mechanical detector returned no findings before the review fixes.
- Finish review scored both requested fixes resolved: saved-history protection
  and correct error presentation. Its ship verdict covers those fixes only.
- Archive validation: Manifest V3, activeTab/scripting/storage permissions only,
  required scripts present, installation guide included.

## Not verified

- Chrome toolbar activation and isolated extension execution: this environment's
  administrator disables unpacked extension loading.
- Actual Chrome extension storage: state unit tests use a mock; the browser
  fixture checks correctly reject unavailable extension storage.
- The supplied Squarespace website: network policy excludes its domain, and the
  web reader could not open the visitor link.
- AI generation, nested dropdown implementation, site publication, published-code
  rollback: these are later milestones, not part of this diagnostic build.

## First owner acceptance test

Install the archive as an unpacked extension in Chrome. Open the trial past its
password screen. Check that the sidebar lists expected links, private preview and
controls work, closing removes the changes, and a saved local draft survives
reopening. Do not add code to Squarespace for this test.
