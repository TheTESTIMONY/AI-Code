# Squarespace assistant: build architecture

The first audience is the owner using Chrome on a Squarespace 7.1 trial. The
initial product focuses on one complete nested-navigation workflow. Product name
and AI provider remain undecided. No public SaaS or billing system is needed yet.

## Stack and responsibilities

| Layer | Choice | Why |
| --- | --- | --- |
| Browser integration | Chrome Manifest V3 | User-activated site inspection; an isolated extension context. |
| Sidebar | React + TypeScript | Shared state across conversation, controls, code, and versions. |
| Bundling | esbuild now; Vite when standalone development needs it | Small scripts with packaged dependencies; no remotely loaded extension code. |
| UI foundation | Native controls and Radix primitives where needed | Accessible controls and predictable keyboard behavior. |
| Customization contract | TypeScript + planned Zod validation | Keep generated code, controls, targets, and values consistent. |
| AI service | Planned Node + TypeScript service | Keep provider credentials out of the extension; validate and record responses. |
| Draft persistence | chrome.storage.local initially | Personal-use local snapshots without an account system. |
| Tests | Vitest + Chromium/Playwright | State/cleanup tests, then browser behavior and real-site acceptance. |

## Runtime flow

```mermaid
flowchart LR
    U[Describe a change] --> S[Chrome sidebar]
    S --> C[Read relevant site context]
    C --> A[AI service]
    A --> V[Validate customization package]
    V --> P[Private preview runtime]
    P --> G[Visual controls]
    G --> D[Save draft version]
    D --> R[Review and Apply]
    R --> W[Verified Squarespace publishing adapter]
    W --> B[Read back and confirm]
```

The sidebar and content adapter communicate with the extension service worker.
The service worker mediates network requests and draft storage. An AI service
must receive only relevant context, not full authenticated editor state or cookies.
Treat extracted page text as data, never as instructions to the generation agent.

## Customization package

A generated design version should contain:

- Stable design ID, version ID, parent version, schema version, creation time.
- Targets: page/section/element IDs, link destinations, folder identity, observed
  labels, and an explicit policy for missing or ambiguous matches.
- Code artifacts: scoped CSS, HTML where needed, and approved behavior modules.
- Control schema: stable control IDs, type, label, group, unit, range, default,
  breakpoint overrides, and a binding to a parameter or CSS variable.
- Settings: current values keyed by stable control ID.
- Dependencies and runtime lifecycle: mount, update, unmount, and cleanup rules.
- Changes summary, validation results, and integration assumptions.

These are planned fields, not a claim that the initial diagnostic build already
implements arbitrary design generation. Its local snapshots currently store only
diagnostic settings and metadata.

Adding a control through conversation must update the package and its binding
together. Preserve existing control IDs and values; define migrations when types
or ranges change. Changing a color or width should update settings without an AI
call. Failed updates preserve the last valid package.

## Draft, preview, save, and apply

- A working draft is editable and may be unsaved.
- A saved version is an immutable snapshot. Saving does not publish.
- Private preview renders a selected saved version or draft in the working tab.
- Applied version is the version actually persisted to the website.
- Discard returns to the working draft's base settings.
- Restore creates a new version from an old snapshot, preserving history.

Publishing must read current destination code, preserve unrelated code, identify
the assistant's owned code region, detect a stale baseline, save, and read back.
Store backups before writes. If multiple settings fields are necessary, do not
claim atomicity; implement recovery for partial writes. Mark a version Applied
only after verification. Later publishing needs explicit user action in the UI.

## Squarespace integration decision

The visitor link is enough for rendered page inspection when reachable, but does
not grant editor writes. A custom-code specification is not an editor-write API.

Test supported integration methods before choosing a publisher:

1. Prefer a documented API with the required capabilities and scopes if available.
2. Evaluate a user-authenticated editor adapter for supported code fields. Verify
   read/save/read-back behavior; isolate brittle editor interactions.
3. Evaluate a one-time installed loader plus approved immutable assets if direct
   field writes are unavailable. Explain the installation and hosting dependency.

Never depend on guessed private endpoints. Do not store Squarespace passwords or
copy session cookies into the AI service. Initial extension permissions are
activeTab, scripting, and storage; no broad persistent host access is requested.

## Preview lifecycle

The current bounded diagnostic runtime scopes a temporary stylesheet through an
owned attribute, observes header replacement, and cleans up its attribute/style.
Its settings accept only a hex color and bounded numeric values.

The eventual customization runtime must avoid duplicate listeners, restore owned
changes on unmount, survive re-rendered targets and page navigation, and report
missing targets. Generated JavaScript executed in the page is not safely sandboxed
by a private preview. Start with validated declarative behavior modules; evaluate
arbitrary code support separately. Extension remote-code and CSP constraints also
need verification before choosing an execution model for generated behavior.

## Milestones and acceptance

1. **Connection probe (this build).** Sidebar, rendered navigation, controlled
   private header preview, control adjustment, local draft snapshots, cleanup.
   Live-site check still required in the owner's Chrome.
2. **Site-specific navigation adapter.** Inspect the actual header and folder
   structure; bind stable targets; test keyboard, touch, mobile gutters, re-render,
   and navigation between pages.
3. **Nested-menu customization.** Deliver desktop submenu and mobile accordion
   behavior, controls, versioned values, preview, disable, and restore. Clarify
   whether this modifies native page hierarchy or supplies a separate menu tree.
4. **AI generation.** Integrate a chosen provider through the service. Generate a
   validated package, preserve context across refinements, surface errors, and
   create controls with stable bindings. Test ambiguity and malformed responses.
5. **Verified publication.** Establish an authorized editor connection; preserve
   existing code; publish, read back, verify in a separate visitor session, restore.
6. **Broader features.** Expand only after the navigation workflow is reliable.

## Evidence and limitations

- Local unit tests cover navigation inspection, settings validation, preview
  cleanup, replaced headers, and mocked extension-storage draft behavior.
- Browser tests render the built sidebar and preview code against a synthetic
  Squarespace-like fixture. Screenshots explicitly label the fixture.
- This environment's administrator disables unpacked extension loading. Toolbar
  activation, isolated-world behavior, and real Chrome storage still need testing
  in the owner's installed extension.
- Workspace network policy excludes Squarespace. The supplied site's DOM and
  code injection access remain unverified.
- AI generation, nested-menu rendering, authenticated publishing, and rollback of
  published code are planned, not implemented in this diagnostic milestone.
