# Squarespace Assistant · Connection Test

An initial personal-use Chrome extension for testing the site connection. It is
not yet the complete AI design tool. It reads rendered navigation, opens a dark
sidebar, and provides a private, reversible header outline/shape preview.

## Try the packaged extension

1. Extract `Squarespace-Assistant-Connection-Test.zip`.
2. Open `chrome://extensions` in Chrome and enable Developer mode.
3. Click **Load unpacked**, then select the extracted `extension` folder containing
   `manifest.json`.
4. Open your Squarespace trial using the visitor link supplied in chat. Enter the
   site password if prompted, and open a page with a visible header.
5. Pin the extension from Chrome's Extensions menu and click its toolbar icon.

Expect a sidebar with **Header detected** and a list of rendered navigation links.
Choose **Try a private preview** to outline the header, then adjust its outline
color/width or corner radius under Controls. The eye button turns preview off.
Closing the sidebar or pressing Escape removes the preview.

**Save draft** stores settings locally in Chrome. It does not save to Squarespace.
Reopen the sidebar, choose the saved version, and turn on preview to restore those
settings. Reloading the page removes temporary previews. **Apply** is disabled:
publishing and AI generation are not connected. This build does not create menus.

If you see `!` on the toolbar icon, hover it for the error. Open the actual site
page rather than Chrome settings or the Squarespace account dashboard. If no
header is detected, go past the password screen and refresh inspection. Custom
domains and the authenticated Squarespace editor are not covered by this first
connector. An organization-managed Chrome may prohibit unpacked extensions.

## Build from source

```sh
npm ci
npm run check
npm test
npm run build
```

Load the generated `dist` folder as an unpacked extension. Node 24 was used for
the initial build. Dependencies are pinned by `package-lock.json`. To rerun the
fixture browser checks, set `CHROMIUM_PATH` to an installed Chromium executable
and run `node scripts/browser-check.mjs`. Those checks do not certify the real
Squarespace site or extension toolbar activation.

## What to report from your first site test

- Whether the sidebar opens and says Header detected.
- Whether it finds the expected folder and pages.
- Whether preview/control adjustment works and closing removes it.
- Whether Save draft survives closing and reopening the sidebar.

Do not send account passwords or session cookies. Authenticated editor access will
be arranged separately when the publishing adapter is ready.

See ARCHITECTURE.md for the selected stack, data contract, milestones, and the
remaining integration decisions. Project-local design skills are in
`.agents/skills`; their sources and revisions are recorded in `sources.json`.
