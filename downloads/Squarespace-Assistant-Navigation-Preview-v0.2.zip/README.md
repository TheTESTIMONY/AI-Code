# Squarespace Assistant · Navigation Preview v0.2

A personal-use Chrome extension for privately previewing the owner's navigation:

- Players → Team.
- Works → Publications, Research → News.

The News nesting follows the owner's supplied dash indentation. Destinations are
read from existing site links, not invented. The native News label may be `News`
or use leading dash markers such as `- - News`. Extra native links are preserved.
Research remains a clickable page with a separate disclosure for its News child.
The preview does not change Squarespace's stored folder hierarchy.

## Update the existing extension

1. Close the assistant sidebar on your site.
2. Extract `Squarespace-Assistant-Navigation-Preview-v0.2.zip`.
3. Copy `manifest.json`, `background.js`, and `probe.js` from the new `extension`
   folder into the **same folder you loaded for v0.1**, replacing those three files.
4. Open `chrome://extensions` and click **Reload** on the existing assistant.
5. Refresh the Squarespace site tab, then click the assistant's toolbar icon.

Reusing the existing folder keeps the extension identity and existing Chrome draft
history. The new nested-menu drafts have a separate history from the header check.
For a first installation, enable Developer mode in `chrome://extensions`, click
**Load unpacked**, and select the extracted `extension` folder.

## Try the nested menu

Open the trial past its password screen. Ensure the native folders are named
**Players** and **Works**, with Team inside Players and Publications, Research,
and News inside Works. Keep all four pages in those native Squarespace folders;
the extension supplies the extra Research → News level in the private preview.

1. Select **Players & Works navigation** (the default design).
2. Click **Preview nested navigation**. A missing/ambiguous link displays a
   specific error and prevents partial changes. Refresh inspection after editing
   the native navigation.
3. Click **Minimize controls to test menu**, or the toolbar's minimize button.
4. On desktop, hover Works and then Research to reveal News. The disclosure button
   also works by click. Research's own link still goes to its page.
5. On mobile/narrow Chrome, open the native mobile navigation, open Works, and tap
   Research's disclosure. News expands inline. The native Back action remains.
6. Click **Show controls** to adjust colors, width, padding, type size, corner
   radius, mobile gutters, and arrow timing without another AI request.
7. Save a local draft, close/reopen the assistant, select that version, and enable
   preview to restore it. Discard restores the current draft's saved/default base.
8. Close the assistant to remove all preview nodes, styles, and owned attributes.

Keyboard: Tab reaches real links and disclosure buttons; Enter/Space toggles a
focused button; ArrowRight on Research enters News; ArrowLeft returns to its
button; Escape closes an open submenu first. Escape elsewhere closes the assistant
and removes the preview. Disclosure rotation is disabled for keyboard initiation
and reduced-motion preferences. At desktop edges the flyout flips left.

**Save draft** persists settings only in Chrome. **Apply** and conversational AI
are not connected. Reloading the page removes the temporary preview. The native
header check remains available under the Design selector. Following a link opens
its real destination and normally resets the tab's temporary preview.

## Verification and limits

The owner confirmed v0.1 real-site launch, header detection, draft save, and close
cleanup. v0.2 has TypeScript/build checks, 20 unit tests and 7 browser behavior checks
on a synthetic Squarespace-like fixture. Its specific native folder layout,
mobile behavior and Squarespace client-side rendering still need owner acceptance.
The workspace cannot independently open the live test site, and its administrator
blocks unpacked extension testing here. Fixture UI storage is deliberately absent;
unit tests mock it.

For a problem, send the sidebar error and a screenshot showing the relevant
navigation. Do not send account passwords, cookies, or authenticated editor state.

## Build from source

```sh
npm ci
npm run check
npm test
npm run build
```

Node 24 was used. Load `dist` as an unpacked extension. For browser fixture checks,
set `CHROMIUM_PATH` to an installed Chromium if required, then run
`node scripts/menu-browser-check.mjs` (nested preview) and
`node scripts/browser-check.mjs` (original header check). Neither certifies real
Squarespace integration or the actual extension toolbar/isolated context here.

See ARCHITECTURE.md for future AI/publishing contracts and TEST-REPORT.md for the
verification scope. Installed design skills are project-local in `.agents/skills`.
