# Initial connector verification

Tested with Node 24, TypeScript, Vitest, and installed Chromium.

## Passed

- TypeScript check and production bundling.
- 11 unit tests: navigation reading, folder context, duplicate links, settings
  validation, idempotent cleanup, header replacement, password-screen rejection,
  preservation of external edits, local draft save/load, write-error reporting,
  and protection after an initial storage-read failure.
- 6 browser fixture checks: built sidebar/navigation rendering, live preview
  settings, truthful unavailable storage/publishing states, close cleanup,
  390px fit and Escape cleanup, no page errors.
- Impeccable mechanical detector returned no findings before the review fixes.
- Finish review scored both requested fixes resolved: saved-history protection
  and correct error presentation. Its ship verdict covers those fixes only.
- Archive validation: Manifest V3, activeTab/scripting/storage permissions only,
  required scripts present, installation guide included.

## Owner-reported live acceptance — 2026-10-09

The owner installed the packaged extension in Chrome and reported:

- The sidebar opens on the supplied Squarespace site.
- The header is detected.
- A draft was saved.
- The temporary edit disappears when the sidebar closes.

This confirms those steps through the owner's report. It does not establish that
the detected navigation matches every actual page, that saved settings survive
reopening, or that mobile, keyboard, and header replacement behavior works on the
real site. Those remain separate acceptance checks.

## Not independently verified

- Chrome toolbar activation and isolated extension execution: this environment's
  administrator disables unpacked extension loading. The owner reported successful
  sidebar launch in their installed Chrome extension.
- Actual Chrome extension storage: state unit tests use a mock; the browser
  fixture checks correctly reject unavailable extension storage. The owner reported
  a successful draft save; persistence after reopening remains unconfirmed.
- The supplied Squarespace website: network policy excludes its domain, and the
  web reader could not open the visitor link.
- AI generation, nested dropdown implementation, site publication, published-code
  rollback: these are later milestones, not part of this diagnostic build.

## Owner acceptance checklist

Install the archive as an unpacked extension in Chrome. Open the trial past its
password screen. Check that the sidebar lists expected links, private preview and
controls work, closing removes the changes, and a saved local draft survives
reopening. Launch, header detection, draft save, and close cleanup were reported
successful on 2026-10-09. Navigation accuracy and reopening persistence remain
unconfirmed. Do not add code to Squarespace for this test.

## Navigation preview v0.2 — 2026-10-09

Implemented requested Players → Team and Works → Publications, Research → News
structure as a private rendered menu. News nesting follows the disclosed working
interpretation of the owner's indentation; no reply to the confirmation question
had arrived during implementation. Native Squarespace page hierarchy is unchanged.

Passed:

- TypeScript check and production bundle (Manifest V3, version 0.2.0).
- 20 unit tests: original connector/cleanup/state checks plus desktop/mobile folder
  resolution, real destinations, dash-marked News, retained extras, missing and
  ambiguous target refusal before mutation, keyboard disclosure, header and
  same-host replacement, transient loss/recovery, bounded menu parameters,
  external-attribute preservation, separate menu history, and immutable snapshots.
- 8 nested-menu browser fixture checks: all desktop/mobile mounts; width/Discard;
  hover and keyboard navigation; submenu Escape preserves the assistant; flyout
  flipping; maximum-width roots and constrained flyouts at an 800px viewport;
  mobile inline disclosure, gutters and native Back; 390px sidebar fit and honest
  unavailable storage/publishing; cleanup with no browser errors.
- 6 original header-check browser fixture checks still pass in the updated build.
- All five current UI captures inspected at 1440px and 390px. Mechanical detector
  ran once; advisories concern existing 13/15px helper typography and the owner's
  separately adjustable menu shadow/radius rather than blocking UI defects.

Unit storage is mocked. Browser behavior checks inject the built bundle as a
regular script against a synthetic fixture, not an unpacked extension in its
isolated context. Actual v0.2 Squarespace DOM, client-side navigation/re-render,
Chrome storage, and desktop/mobile interactions require owner acceptance. The
owner's reported v0.1 success does not certify the new nested menu. AI generation,
editor writes, permanent Apply and published-code rollback remain unimplemented.
