"use strict";
(() => {
  // src/extension/background.ts
  chrome.action.onClicked.addListener(async (tab) => {
    if (!tab.id) return;
    const id = tab.id;
    try {
      const url = new URL(tab.url ?? "");
      if (!url.hostname.endsWith(".squarespace.com") || url.protocol !== "https:") {
        throw new Error("Open the Squarespace trial site first.");
      }
      await chrome.scripting.executeScript({ target: { tabId: id }, files: ["probe.js"] });
    } catch (error) {
      await chrome.action.setBadgeText({ tabId: id, text: "!" });
      await chrome.action.setTitle({ tabId: id, title: error instanceof Error ? error.message : "Connection failed" });
    }
  });
  chrome.runtime.onMessage.addListener((message, sender) => {
    if (sender.id !== chrome.runtime.id || !sender.tab?.id || message?.type !== "probe-result") return;
    const tabId = sender.tab.id;
    const result = message;
    void chrome.storage.session.set({ [`inspection:${tabId}`]: result });
    void chrome.action.setBadgeText({ tabId, text: result.error ? "!" : result.preview ? "P" : "" });
    void chrome.action.setBadgeBackgroundColor({ tabId, color: "#3451c5" });
    void chrome.action.setTitle({ tabId, title: result.error ?? (result.preview ? "Private preview active. Click to remove." : "Preview nested navigation") });
  });
  chrome.tabs.onUpdated.addListener((tabId, change) => {
    if (change.status !== "loading") return;
    void chrome.action.setBadgeText({ tabId, text: "" });
    void chrome.action.setTitle({ tabId, title: "Preview nested navigation" });
    void chrome.storage.session.remove(`inspection:${tabId}`);
  });
  chrome.tabs.onRemoved.addListener((tabId) => {
    void chrome.storage.session.remove(`inspection:${tabId}`);
  });
})();
